<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>

</head>
<body>
    <div class="nav">
        <a href="dasboard.php">Home</a>
        <a href="data_buku.php">Data Buku</a>
        <a href="data_pengguna.php">Data Pengguna</a>
    </div>

    <?php 
    session_start();
    if (!isset($_SESSION['user'])) {
        # code.....
        header("Location: login.php");
    }

    ?>

    <div class="content">
        <h1>Ini Halaman Utama</h1>
        halo,<?php echo $_SESSION['user']['username']; ?>
    </div>

    <a href = "LogOut.php">
        LogOut



</body>
</html>