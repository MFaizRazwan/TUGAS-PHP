<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="nav">
        <a href="dashboard.php">Home</a>
        <a href="data_buku.php">Data Buku</a>
        <a href="data_pengguna.php">Data Pengguna</a>
    </div>

    <div class="content">
        <h1>Ini Halaman Data Pengguna</h1>
    </div>
</body>
</html>